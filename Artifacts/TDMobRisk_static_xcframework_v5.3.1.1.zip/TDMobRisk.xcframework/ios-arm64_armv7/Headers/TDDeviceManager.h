//
//  TDDeviceManager.h
//  TDMobRisk
//
//  Created by LEE on 4/21/25.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN



typedef struct TDDeviceAPIStatus_Void {
    /// code
    int code;
    /// message
    char *message;
    
} TDDeviceAPIStatus;

typedef struct TDDeviceResponse_Void {
  /// fpVersion, SDK version.
  char *fpVersion;
  /// blackBox, an identifier that uniquely identifies the request associated with the API call.
  char *blackBox;
  /// anonymousId, an identifier that uniquely identifies the device.
  char *anonymousId;
  /// deviceRiskScore, a score that reflects the safety status of the device.
  int deviceRiskScore;
  /// apiStatus, API call status.
  TDDeviceAPIStatus apiStatus;
  /// sealedResult, cipher of device details from the server.
  char *sealedResult;
    
} TDDeviceResponse;


typedef void(^TDDeviceInfoCallback)(TDDeviceResponse response);

typedef struct TDDeviceManager_Void {
    /**
     * Initialization
     * @param options Initialization parameters, please see the document for details.
     */
    void (*initWithOptions)(NSDictionary *options);
    /**
     * Get device information
     * @usage: manager->getDeviceInfo(^(TDDeviceResponse response){});
     */
    void (*getDeviceInfo)(TDDeviceInfoCallback callback);
    /**
    * get sdkVersion
    */
    NSString *(*getSDKVersion)(void);

} TDDeviceManager_t;

@interface TDDeviceManager : NSObject
/**
 * Get a singleton object
 */
+ (TDDeviceManager_t *)sharedManager;

@end

NS_ASSUME_NONNULL_END

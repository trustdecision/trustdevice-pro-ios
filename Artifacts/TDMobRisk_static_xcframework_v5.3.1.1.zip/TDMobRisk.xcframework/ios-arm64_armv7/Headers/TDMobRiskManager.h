//
//  TDMobRiskManager.h
//  TDMobRisk
//

#import <Foundation/Foundation.h>
#import "TDDeviceManager.h"


#define TDMOBRISK_SDK_VERSION @"5.3.1.1"


typedef enum {
    
    TDLivenessShowStylePush,

    TDLivenessShowStylePresent,
    
} TDLivenessShowStyle;

typedef enum {
    
    // The Captcha is verified successfully, and a valid validateToken can be obtained at this time;
    TDShowCaptchaResultTypeSuccess,
    // If the Captcha fails, you can get the error code errorCode and errorMsg, and check the cause according to the `Error code` in the document;
    TDShowCaptchaResultTypeFailed,
    // The Captcha window pop-up is successful, waiting to be verified;
    TDShowCaptchaResultTypeReady,
    
} TDShowCaptchaResultType;

typedef void(^TDGetBlackBoxAsyncBlock)(NSString* blackBox);

typedef void(^TDErrorCodeBlock)(int errorCode, const char*errorMsg);

typedef struct _TDShowCaptchaResultStruct{
    
    // return result type
    const TDShowCaptchaResultType resultType;
    // After returning successfully, the token of the Captcha returned
    char* const validateToken;
    // After the return fails, the returned error code can be checked according to the document
    const NSInteger errorCode;
    // Return error message after failure
    char* const errorMsg;
    
}TDShowCaptchaResultStruct;

typedef void(^TDShowCaptchaBlock)(TDShowCaptchaResultStruct resultStruct);

typedef void(^TDLivenessResultBlock)(NSDictionary* resultDictionary);

typedef struct _TDAPISignResult{
    // sign
    char* sign;
    // After the return fails, the returned error code can be checked according to the document
    int code;
    // Return error message after failure
    char* msg;
}TDAPISignResult;

typedef struct _TDBehaviorResultStruct{
    // Return code, 0 indicates success.
    const NSInteger code;
    // behavior data
    char* const payload;
    // Error messages when it fails
    char* const msg;
}TDBehaviorResultStruct;

typedef struct _tdMobRiskVoid {
/**
 * Initialization method
 * @param options Initialization parameters，please see the document for details.
 */
void (*initWithOptions)(NSDictionary *);
/**
 * get blackBox sync, you should make sure that method calls after initWithOptions.
 */
NSString *(*getBlackBox)(void) __attribute__ ((deprecated));
/**
* get blackBox async, you should make sure that method calls after initWithOptions.
  @usage: manager->getBlackBoxAsync(^(NSString* blackBox){});
*/
void (*getBlackBoxAsync)(TDGetBlackBoxAsyncBlock block) __attribute__ ((deprecated));
/**
* Get device information
* @usage: manager->getDeviceInfo(^(TDDeviceResponse response){});
*/
void (*getDeviceInfo)(TDDeviceInfoCallback callback);
/**
* Get device information
* @usage: manager->getDeviceInfo(^(TDDeviceResponse response){});
*/
TDDeviceResponse (*getDeviceInfoSync)(void);
/**
* listen error code, use it before initWithOptions
* @usage: manager->setOnErrorCodeListener(^(int errorCode,const char* errorMsg){})
*/
void (*setOnErrorCodeListener)(TDErrorCodeBlock block);
/**
 * Display Captcha window
 * @usage: manager->showCaptcha(self.view,^(TDShowCaptchaResultStruct resultStruct) {
 * });
 * @param superView The parent view where the popup is displayed, UIView type
 * @param block result callback block
 */
void (*showCaptcha)(id superView,TDShowCaptchaBlock block);
    
/**
 * Display Captcha window
 * @usage: manager->showCaptcha(self.view,^(TDShowCaptchaResultStruct resultStruct) {
 * });
 * @param superView The parent view where the popup is displayed, UIView type
 * @param sceneToken scene token
 * @param block result callback block
 */
void (*showCaptchaWithToken)(id superView,NSString* sceneToken,TDShowCaptchaBlock block);
    
/**
 * Display Liveness window, will use [targetVC.navigationController pushViewController:lvctl animated:YES]; to show
 * @usage: manager->showLiveness(self,^(NSDictionary* successResultDictionary) {
 * },^(NSDictionary* failResultDictionary) {
 * });
 * @param targetVC The parent view where the popup is displayed, UIViewController type
 * @param block result callback block
*/
void (*showLiveness)(id targetVC,TDLivenessResultBlock successBlock,TDLivenessResultBlock failBlock);
    
/**
* Display Liveness window
* @usage: manager->showLivenessWithShowStyle(self,@"replace your license" ,TDLivenessShowStylePush,^(NSDictionary* successResultDictionary) {
* },^(NSDictionary* failResultDictionary) {
* });
* @param targetVC The parent view where the popup is displayed, UIViewController type
* @param license auth license,can be nil
* @param showStyle TDLivenessShowStylePush or TDLivenessShowStylePresent
* @param block result callback block
*/
void (*showLivenessWithShowStyle)(id targetVC,NSString* _Nullable license,TDLivenessShowStyle showStyle,TDLivenessResultBlock successBlock,TDLivenessResultBlock failBlock);
/**
* upload probe data
*/
void (*upload)(void);
    
/**
* TDBehavior start，start behavior collect, write collected data into SDK internal container
*/
void (*start)(void);
    
/**
* TDBehavior stop，end behavior collect, stop writing collected data into SDK internal container and clear the data in SDK internal container;
*/
void (*stop)(void);

/** TDBehavior collect, return behavior collect result, if data exists in SDK internal container, it will return success code == 0, and clear the data in SDK internal container;
* If no data exists in SDK internal container, it will return code == 104 error code
*/
TDBehaviorResultStruct (*collect)(void);

/**
 * Sign the queryDictionary parameter dictionary under the path
 * @usage: const char* sign = manager->sign(@"login");
 * @param path: network request path, such as: @"login"
*/
TDAPISignResult (*sign)(NSString *path);
    
/**
* get sdkVersion
*/
NSString *(*getSDKVersion)(void);

} TDMobRiskManager_t;

@interface TDMobRiskManager : NSObject
/**
 * get  a singleton object
 */
+ (TDMobRiskManager_t *)sharedManager;

@end
